# Via

#### Pure, Customize, Fast, Small

#### Download
* [Download from Google Play](https://play.google.com/store/apps/details?id=mark.via.gp)

* [Download from CoolApk](http://coolapk.com/apk/mark.via)

### Help with localization

We encourage everyone to help with localization. The following is how to do.

1. Fork this repository

2. Translate ````strings.xml```` at this [link](https://github.com/LakorTi/Via/blob/master/app/src/main/res/values/strings.xml) to your own language then save it as ````string.xml````

3. Copy it to the right path, like app/src/main/res/value-zh

4. Make a Pull Request